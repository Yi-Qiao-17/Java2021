import javax.swing.*;
import java.awt.Color;
import java.awt.*;
import java.awt.event.*;
public class finalproject extends JFrame 
				 implements ActionListener {
	private JLabel rule1,rule2,rule3,rule4,rule5,rule6,rule7,rule8,rule9,goal;
    private JButton btn1,btn2,btn3;
	private JLayeredPane layeredPane;
	private Timer timer;
	int ballgo=0,fballgo=0,isgoal=0,isbtn1=0;
	int x1,y1,x2,y2,prex,prey,nowx,nowy, w,h,dx,dy,ndx,ndy;
	int oldx=400,oldy=400,preoldx=400,preoldy=400,prex1,prey1,offset=0;
	double dw,dh;
	public finalproject() {
		super("�@�H���y");
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setSize(1800, 900);
		setVisible(true); 
		
		setLayout(new GridLayout(1, 1));//?���O?�m���I�楬���A�u�w?�@��@�C�A��?���R?��?���O�A�}�i�H??���O����j�M?�p��?
		
		layeredPane = new JLayeredPane() {
			public void paintComponent(Graphics g) {//��??��O����k
				super.paintComponent(g);//�M���e�����I����m
				ImageIcon image = new ImageIcon("desk.jpg");//?�J?��
				g.drawImage(image.getImage(), 0, 0,1500,800, this);//���s?��O	
				if(ballgo==1){
					if(fballgo==0){
						dx=x1-oldx;
						dy=y1-oldy;
						w=x2-x1;
						h=y2-y1;
						int nw=0,nh=0;
						if(w<=0){
							w=-w;
							nw=1;
						}
						if(h<=0){
							h=-h;
							nh=1;
						}
						System.out.println("w = "+w+" h = "+h);
						if(w==0||h==0){
							if(w==0){
								if(nh==1){
									h=-50;
								}
								else{
									h=50;
								}
							}
							else if(h==0){
								if(nw==1){
									w=-50;
								}
								else{
									w=50;
								}
							}
						}
						else if(w>h){
							dw=w/h;
							dh=h/h;
							if(dw-dh<1){
								dw*=50;
								dh*=50;
							}
							else if(dw-dh<10){
								dw*=5;
								dh*=5;
							}
							System.out.println("dw = "+dw+" dh = "+dh);
							if(nw==1&&dw>=0){
								dw=-dw;
							}
							if(nh==1&&dh>=0){
								dh=-dh;
							}
							w= (int) Math.round(dw);
							h= (int) Math.round(dh);
						}
						else{
							dw=w/w;
							dh=h/w;
							if(dh-dw<1){
								dw*=50;
								dh*=50;
							}
							else if(dh-dw<10){
								dw*=5;
								dh*=5;
							}
							System.out.println("dw = "+dw+" dh = "+dh);
							if(nw==1&&dw>=0){
								dw=-dw;
							}
							if(nh==1&&dh>=0){
								dh=-dh;
							}
							w= (int) Math.round(dw);
							h= (int) Math.round(dh);
						}
						System.out.println("w = "+w+" h = "+h+" dx = "+dx+" dy = "+dy);
					}					
				    g.setColor(Color.white);
					g.fillOval(oldx-12,oldy-45,50,50);
					g.setColor(Color.black);
					g.drawOval(oldx-12,oldy-45,50,50);
					preoldx=oldx;
					preoldy=oldy;
					prex1=x1;
					prey1=y1;
					System.out.println("fballgo = "+fballgo+" oldx = "+oldx+" oldy = "+oldy+" preoldx = "+preoldx+" preoldy = "+preoldy);
					if(((oldx<104&&oldx>84)||(oldx>727&&oldx<747)||(oldx>1362&&oldx<1382))&&((oldy<125&&oldy>120)||(oldy>720&&oldy<725))){
						isgoal=1;
						ballgo=0;
						fballgo=0;
						timer.stop();
						repaint();
					}
					oldx=x1-w-dx;
					oldy=y1-h-dy;
					x1=oldx+dx;
					y1=oldy+dy;
					while((oldx<=84)||(oldx>=1382)){
						oldx=prex1+w+dx;
						x1=oldx+dx;
						prex1=x1;
						w=-w;
					}
					while((oldy<=120)||(oldy>=725)){
						oldy=prey1+h+dy;
						y1=oldy+dy;
						prey1=y1;
						h=-h;
					}
					fballgo++;
				}
				if(isgoal==1){
					Font fnt3=new Font("Serief",Font.BOLD,100);
					goal = new JLabel("GOAL");
					goal.setBounds(610,320, 400, 150);
					goal.setForeground(Color.white);
					goal.setFont(fnt3);
					goal.setVisible(true);
					layeredPane.add(goal);
					isgoal=0;
					fballgo=0;
					btn1.setText("���s�C��");
				}
			}
		};
		
		
		Font fnt=new Font("Serief",Font.BOLD,22);
		
		btn1 = new JButton("�}�l�C��");
        btn1.setBounds(1550,50,180,50);
		btn1.setBackground(new Color(72,61,139));
		btn1.setForeground(Color.white);
		btn1.setFont(fnt);
        btn1.setFocusable(false);//?�m��?�o�J?�A�קK?�o�J?�Z�A��??�e��?�A?�PJLabel?�k?��
		btn1.setMnemonic(KeyEvent.VK_S);  // �]�w����
        btn1.addActionListener(this); // ���U�ƥ�B�z
		btn1.setVisible(true);			
		layeredPane.add(btn1);
		
		btn2 = new JButton("�T�w���y");
        btn2.setBounds(1550,120,180,50);
		btn2.setBackground(new Color(72,61,139));
		btn2.setForeground(Color.white);
		btn2.setFont(fnt);
        btn2.setFocusable(false);//?�m��?�o�J?�A�קK?�o�J?�Z�A��??�e��?�A?�PJLabel?�k?��
		btn2.setMnemonic(KeyEvent.VK_S);  // �]�w����
        btn2.addActionListener(this); // ���U�ƥ�B�z
		btn2.setVisible(true);				
		layeredPane.add(btn2);
		
		btn3 = new JButton("�C������");
        btn3.setBounds(1550,190,180,50);
		btn3.setBackground(new Color(72,61,139));
		btn3.setForeground(Color.white);
		btn3.setFont(fnt);
        btn3.setFocusable(false);//?�m��?�o�J?�A�קK?�o�J?�Z�A��??�e��?�A?�PJLabel?�k?��
		btn3.setMnemonic(KeyEvent.VK_S);  // �]�w����
        btn3.addActionListener(this); // ���U�ƥ�B�z
		btn3.setVisible(true);			
		layeredPane.add(btn3);
		
		Font fnt2=new Font("Serief",Font.BOLD,18);
		
		rule1 = new JLabel("���k:");
		rule1.setBounds(1550,260, 200, 50);
		rule1.setFont(fnt2);
		layeredPane.add(rule1);
		rule2 = new JLabel("1.�Х��I���ղy�A");
		rule2.setBounds(1550,310, 200, 50);
		rule2.setFont(fnt2);
		layeredPane.add(rule2);
		rule3 = new JLabel("2.�é�ԥX���y��A");
		rule3.setBounds(1550,360, 200, 50);
		rule3.setFont(fnt2);
		layeredPane.add(rule3);
		rule4 = new JLabel("3.��n���y���סA");
		rule4.setBounds(1550,410, 200, 50);
		rule4.setFont(fnt2);
		layeredPane.add(rule4);
		rule5 = new JLabel("4.��}�ƹ��A");
		rule5.setBounds(1550,460, 200, 50);
		rule5.setFont(fnt2);
		layeredPane.add(rule5);
		rule6 = new JLabel("5.�Y�n���s�վ�A");
		rule6.setBounds(1550,510, 200, 50);
		rule6.setFont(fnt2);
		layeredPane.add(rule6);
		rule7 = new JLabel("6.���s�B�J1-4�A");
		rule7.setBounds(1550,560, 200, 50);
		rule7.setFont(fnt2);
		layeredPane.add(rule7);
		rule8 = new JLabel("7.�̫���U�T�w���y�A");
		rule8.setBounds(1550,610, 200, 50);
		rule8.setFont(fnt2);
		layeredPane.add(rule8);
		rule9 = new JLabel("8.��i�N�y�����X�h�C");
		rule9.setBounds(1550,660, 200, 50);
		rule9.setFont(fnt2);
		layeredPane.add(rule9);
		
		addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent evt) {
				x1=evt.getX();
				y1=evt.getY();
				System.out.println("x1 : " +x1+" y1 = "+y1);
			}
			public void mouseReleased(MouseEvent evt){
				Graphics g=getGraphics();
				x2=evt.getX();
				y2=evt.getY();
				System.out.println("x2 : " +x2+" y2 = "+y2);
				g.setColor(Color.white);
				g.fillOval(oldx,oldy,50,50);
				g.setColor(Color.black);
				g.drawOval(oldx,oldy,50,50);
				g.drawLine(x1,y1,x2,y2);
			}
		});
		
		addMouseMotionListener(new MouseMotionAdapter() {
			public void mouseMoved(MouseEvent e){}
			public void mouseDragged(MouseEvent e){
				Graphics g=getGraphics();
				nowx=e.getX();
				nowy=e.getY();
				repaint();
				g.setColor(Color.white);
				g.fillOval(oldx,oldy,50,50);
				g.setColor(Color.black);
				g.drawOval(oldx,oldy,50,50);
				g.drawLine(x1,y1,nowx,nowy);	
				
			}
			public void mouseEntered(MouseEvent e){}
			public void mouseExited(MouseEvent e){}
			public void mouseClicked(MouseEvent e){}
		});
		
		timer = new Timer(20, this);
        timer.setInitialDelay(0);
		timer.start();
		
		add(layeredPane);	
		
    }
					
	public void actionPerformed(ActionEvent evt) {
      // �P�_�ƥ�ӷ�������
      if (evt.getSource() == btn1) {
		  if(isbtn1==0){
			  
		  }
		  else{
			  goal.setVisible(false);
		  }
		  isbtn1++;
		  oldx=400;
		  oldy=400;
		  preoldx=400;
		  preoldy=400;
		  Graphics g=getGraphics();
		  g.setColor(Color.white);
		  g.fillOval(oldx,oldy,50,50);
		  g.setColor(Color.black);
		  g.drawOval(oldx,oldy,50,50);		  	  
	  }
	  else if (evt.getSource()==btn2){
		  ballgo=1;
	  }
	  else if (evt.getSource()==btn3){
		  timer.stop();
	  }
	  if(ballgo==1){
		  offset++;
		if (offset>20){
			oldx=preoldx;
			oldy=preoldy;
			timer.stop();
			ballgo=0;
			fballgo=0;
			offset=0;
		}
		else{  
			repaint();
		}
	  }
	  timer.restart();
   }
   
    public static void main(String[] args) {
        // finalproject app = new finalproject();
		// app.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		// app.setSize(1800, 900);
		// app.setVisible(true); 
    }
    
}