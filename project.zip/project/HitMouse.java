import java.awt.*;
import java.awt.event.*;
import java.util.Random;
import javax.swing.*;

  
public class HitMouse extends JFrame implements ActionListener, MouseListener{  
    boolean isOver = false;//game is over? 
    JLabel jlbMouse;//pui pui
    Timer timer;//�ɶ��w�ɾ�
    Random random;  
    int delay = 1000;//milliseconds
    Toolkit tk;
    Image image;
    Cursor myCursor;
    JLabel currentGrade, hitNum;
    int showNumber = 0, hitNumber = 0, currentGrades = 1;

    public HitMouse(){  
        super("");
    }
    void launch() {
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(600, 500);
        setLocationRelativeTo(null);//�]�w�����b�ù�����
        setbackground("beijing.jpg");
        getContentPane().setLayout(null);
        //set cursor img
        tk = Toolkit.getDefaultToolkit();
        image = tk.createImage("hammer.png");
        myCursor = tk.createCustomCursor(image, new Point(0,0), "xxx");
        setCursor(myCursor);

        setMessage();//set score and level
        ImageIcon imageMouse = new ImageIcon("dishu.png");
        jlbMouse = new JLabel(imageMouse);
        jlbMouse.setSize(100,100);
        getContentPane().add(jlbMouse);
        jlbMouse.setVisible(false);  
        jlbMouse.addMouseListener(this);
        //�w�ɾ�  
        timer = new Timer(delay, this);  
        random = new Random();  
        timer.start();  

        addMenu();

        setResizable(false);//can not change window size
        setVisible(true);
    }

    private void addMenu() {
        JMenuBar menubar = new JMenuBar();
        this.setJMenuBar(menubar);
        JMenu game = new JMenu("Options");
        //JMenu bg = new JMenu("Background");

        JMenuItem jitemNew = new JMenuItem("New game");
        jitemNew.setActionCommand("new");
        jitemNew.addActionListener(this);
        JMenuItem jitemPause = new JMenuItem("Pause");
        jitemPause.setActionCommand("pause");
        jitemPause.addActionListener(this);
        JMenuItem jitemExit = new JMenuItem("Exit");
        jitemExit.setActionCommand("exit");
        jitemExit.addActionListener(this);
        game.add(jitemNew);
        game.add(jitemPause);
        game.addSeparator();//���̳]�w���j�u
        game.add(jitemExit);
        menubar.add(game);
    }  

    private void setbackground(String bg) {
        ((JPanel)(this.getContentPane())).setOpaque(false);//�z��
        ImageIcon bgImage = new ImageIcon(bg);
        JLabel bgLabel = new JLabel(bgImage);
        bgLabel.setBounds(0, 25, bgImage.getIconWidth(), bgImage.getIconHeight());
        this.getLayeredPane().add(bgLabel, Integer.valueOf(Integer.MIN_VALUE));//set background the lowest level 
          
    }  

    private void setMessage() {  
        JLabel hitLabel = new JLabel("SCORE");
        hitLabel.setFont(new Font("Serif", Font.PLAIN, 18));
        hitLabel.setBounds(210, 8, 90, 80);
        this.getContentPane().add(hitLabel);
        hitNum = new JLabel("0");
        hitNum.setFont(new Font("Serif", Font.PLAIN, 18));
        hitNum.setBounds(310, 8, 50, 80);
        this.getContentPane().add(hitNum);

        JLabel gradeLabel = new JLabel("LEVEL");
        gradeLabel.setFont(new Font("Serif", Font.PLAIN, 18));
        gradeLabel.setBounds(410, 8, 90, 80);
        this.getContentPane().add(gradeLabel);
        currentGrade = new JLabel("1");
        currentGrade.setFont(new Font("Serif", Font.PLAIN, 18));
        currentGrade.setBounds(510, 8, 50, 80);
        this.getContentPane().add(currentGrade);
    }

    public void actionPerformed(ActionEvent e) {
        //menu
        if(e.getSource() instanceof JMenuItem){
            timer.stop();
            menuItemFun(e);
            timer.start();
        }

        int ran = random.nextInt(9);//0~8
        ImageIcon imageMouse = new ImageIcon("dishu.png");
        jlbMouse.setIcon(imageMouse);
        switch(ran){
        case 0:jlbMouse.setLocation(65, 68);break;
        case 1:jlbMouse.setLocation(450, 288);break;
        case 2:jlbMouse.setLocation(280, 280);break;
        case 3:jlbMouse.setLocation(60, 295);break;
        case 4:jlbMouse.setLocation(407, 175);break;
        case 5:jlbMouse.setLocation(260, 193);break;
        case 6:jlbMouse.setLocation(40, 178);break;
        case 7:jlbMouse.setLocation(430, 75);break;
        case 8:jlbMouse.setLocation(290, 83);break;
        }

        jlbMouse.setVisible(true);

        showNumber++;

        if(!gamePlan()){//game over or not, show the game
            timer.stop();
        }

    }  
    //menu function
    private void menuItemFun(ActionEvent e) {
        if (e.getActionCommand().equalsIgnoreCase("new")) {//new game
            timer.stop();
            showNumber=0;
            hitNumber=0;
            currentGrades=1;
            delay=1000;
            isOver=false;
            hitNum.setText(""+ hitNumber);
            currentGrade.setText(""+ currentGrades);
            timer = new Timer(delay,this);
            timer.start();
            //launch();
        }
        if (e.getActionCommand().equalsIgnoreCase("exit")) {//exit
            //timer.stop();
            System.exit(DISPOSE_ON_CLOSE);
        }     
        if (e.getActionCommand().equalsIgnoreCase("pause")) {//pause
            timer.stop();
            JOptionPane.showMessageDialog(this, "Press 'OK' to continue.");
            timer.start();
        }
        if (e.getActionCommand().equalsIgnoreCase("grass")) {//exit
            setbackground("beijing.jpg");
        } 
        if (e.getActionCommand().equalsIgnoreCase("ocean")) {//exit
            setbackground("ocean.jpg");
        } 

    }

    private boolean gamePlan() {
        if(showNumber-hitNumber > 4){//miss 5 times, game over
            JOptionPane.showMessageDialog(this, "Game Over !");
            isOver = true;
            return false;
        }  
        if(hitNumber%5 == 0 && hitNumber != 0){
            //hitNumber=0;
            showNumber = hitNumber;//reset showNumber
            currentGrades++;
            if(delay > 100){
                delay -= 50;
            }else if(delay >= 500){
                delay = 500;
            }
            timer.setDelay(delay);
            //hitNum.setText(""+hitNumber);
            currentGrade.setText(""+currentGrades);
        }
        return true;
    }

    public void mouseClicked(MouseEvent e) {}

    public void mousePressed(MouseEvent e) {
        if(isOver){  
            return;  
        }
        image = tk.createImage("hammer1.png");
        myCursor = tk.createCustomCursor(image, new Point(0,0), "xxx");
        this.setCursor(myCursor);//�ƹ����U�ɡA�ƹ���ܥ��U�h���Ϥ��A���������ʧ@
        //�p�G�����a���A�h�a�������Q�������Ϥ��A�����a���Q��
        if(e.getSource()==jlbMouse){
            ImageIcon imageIconHit = new ImageIcon("datou.png");
            jlbMouse.setIcon(imageIconHit);
            jlbMouse.setVisible(true);
        }
          
        hitNumber++;
        hitNum.setText(""+hitNumber);
    }

    public void mouseReleased(MouseEvent e) {  
        if(isOver){  
            return;  
        }  
        //���ƹ����P�H��A�ƹ��ܦ^��ӨS���U�ɪ��Ϥ�  
        image = tk.createImage("hammer.png");  
        myCursor = tk.createCustomCursor(image, new Point(0,0), "xxx");  
        this.setCursor(myCursor);  
    }  

    public void mouseEntered(MouseEvent e) {}  

    public void mouseExited(MouseEvent e) {}  

    public static void main(String[] args) {  
        // HitMouse game = new HitMouse();
        // game.launch();
    }
}