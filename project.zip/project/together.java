import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class together   extends HitMouse
{
	public together() {

		setbackground();
		setResizable(false);

		ImageIcon icon1 = new ImageIcon("8-Ball-Pool.png");
		JLabel lb1 = new JLabel(icon1);
		lb1.setLocation(10,280);
		lb1.setSize(140,140);
		lb1.addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent me){
				finalproject app = new finalproject();
			}
		});
		getContentPane().add(lb1);
		ImageIcon icon2 = new ImageIcon("whackamole.png");
		JLabel lb2 = new JLabel(icon2);
		lb2.setLocation(165,280);
		lb2.setSize(140,140);
		lb2.addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent me){
				HitMouse game = new HitMouse();
					game.launch();
			}
		});
		getContentPane().add(lb2);
		ImageIcon icon3 = new ImageIcon("breaker.jpg");
		JLabel lb3 = new JLabel(icon3);
		lb3.setLocation(320,280);
		lb3.setSize(140,140);
		lb3.addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent me){
				JFrame frame = new JFrame();
					BrickBreaker game = new BrickBreaker();
					JButton button = new JButton("restart");
					frame.setSize(350, 450);
					frame.setDefaultCloseOperation(DISPOSE_ON_CLOSE);

					frame.add(game);
					frame.add(button, BorderLayout.SOUTH);
					frame.setLocationRelativeTo(null);
					frame.setResizable(false);
					frame.setVisible(true);
					button.addActionListener(game);

					game.addKeyListener(game);
					game.setFocusable(true);
					Thread t = new Thread(game);
					t.start();
			}
		});
		getContentPane().add(lb3);
		getContentPane().setLayout(null);
		setTitle("Final Project");
	}
	void setbackground() {
        ((JPanel)(this.getContentPane())).setOpaque(false);//�z��
        ImageIcon bgImage = new ImageIcon("giphy.gif");
        JLabel bgLabel = new JLabel(bgImage);
        bgLabel.setBounds(0, 0, bgImage.getIconWidth(), bgImage.getIconHeight());
        this.getLayeredPane().add(bgLabel, Integer.valueOf(Integer.MIN_VALUE));//set background the lowest level        
    } 
	 public static void main(String[] args) {
        together g = new together();
		
		g.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		g.setSize(490, 710);
		g.setVisible(true); 
    }
}